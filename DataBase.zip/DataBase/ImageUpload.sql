select * from image_model;
desc image_model;
drop table image_model;
show tables;

delete from image_model where id=2;
commit;



